Nexus files with each protein multiple sequence alignment in the FRG dataset. All files
include an ASSUMPTIONS block with charsets. The relevant charsets are:

CHARSET SS_HELIX = list of sites... ;
CHARSET SS_SHEET = list of sites... ;
CHARSET SS_COIL  = list of sites... ;
CHARSET EXPOSED  = list of sites... ;
CHARSET BURIED  = list of sites...;
CHARSET INSIDE  = list of sites...;
CHARSET OUTSIDE  = list of sites...;
CHARSET MEMBRANE  = list of sites...;

Each file also includes a PAUP block that will export the relevant subsets of the data if
the file is executed in PAUP* (Swofford 2018; available from http://paup.phylosolutions.com)