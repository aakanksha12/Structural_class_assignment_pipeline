Rate matrices for each structurally-defined subset of the FRG dataset. All .dat files
have the relevant rate matrix in a format usable by programs such as PAML (codeml) and
IQ-TREE. The order of the amino acids is:

Ala Arg Asn Asp Cys Gln Glu Gly His Ile Leu Lys Met Phe Pro Ser Thr Trp Tyr Val