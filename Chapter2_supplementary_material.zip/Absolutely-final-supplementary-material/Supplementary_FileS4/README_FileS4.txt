Log and output files (.log and .iqtree) files from IQ-TREE (Nguyen et al. 2015) analyses of
the exposed and buried subsets of the FRG dataset using the ML variants of Bayesian the CAT 
models (Le et al. 2008).


Le SQ, Gascuel O, Lartillot N. 2008. Empirical profile mixture models for phylogenetic 
reconstruction. Bioinformatics 24:2317–2323.

Nguyen L-T, Schmidt HA, von Haeseler A, Minh BQ. 2015. IQ-TREE: A Fast and Effective 
Stochastic Algorithm for Estimating Maximum-Likelihood Phylogenies. Mol. Biol. Evol. 32:268–274.